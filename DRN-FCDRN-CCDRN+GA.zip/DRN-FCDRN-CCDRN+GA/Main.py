import pandas as pd
from Module.BuildModel import *
from sklearn.metrics import mean_squared_error as MSE
from sklearn.metrics import mean_absolute_error as MAE
import numpy as np
import torch.nn.functional as F
import torch.nn as nn
from torchsummary import summary
from sklearn.preprocessing import StandardScaler
import joblib
import matplotlib.pyplot as plt
import torch
from tqdm import tqdm
import geatpy as ea
from copy import deepcopy
from sklearn.svm import SVR
from joblib import dump, load
import json
import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
#用来正常显示负号
plt.rcParams['axes.unicode_minus']=False
plt.rcParams['font.sans-serif'] = ['simsun']

###############可调整参数#######################
#输入属性
inCols = ['Reaction Temperature/℃', 
          'Resident time/h', 
          'Reaction Pressure/Mpa',
          'Pt loading/wt%', 
          'Mn loading/wt%',
          'TOF/h-1 (calculated from the metal dispersion obtained by TEM)',
          ]
#输出属性
outCols = ['Conversion/%', 
            'GA%', 
            'GAD%',
            'CO2%',
            'FA%']
#实验数据路径
expDataPath = "Static/Exdata.xlsx"
#模拟数据路径
simDataPath = "Static/Simdata.xlsx"
#验证比例
valRate = 0.1
#测试比例
testRate = 0.1
#残差块节点数 区间
nodeArea = [20,80]
#残差块数
resArea = [2,4]
#冻结层数
freezeArea = [0,2]
#神经网络迭代次数
epochs = 1000
#神经网络学习率
lr = 1e-4
#随机种子
seed = 0
# 遗传算法最大进化代数
MAXGEN = 20
# 遗传算法每一代的个体数
NIND = 5
##############################################



#读取数据
expData = pd.read_excel(expDataPath)[inCols+outCols]
simData = pd.read_excel(simDataPath)[inCols+outCols]
data = pd.concat([expData,simData])

#数据标准化
xScaler = StandardScaler().fit(data[inCols])
yScaler = StandardScaler().fit(data[outCols])
data[inCols] = xScaler.transform(data[inCols].values).reshape(-1,len(inCols)).tolist()
data[outCols] = yScaler.transform(data[outCols].values).reshape(-1,len(outCols)).tolist()
joblib.dump(xScaler, "Static/xScaler.pkl")
joblib.dump(yScaler, "Static/yScaler.pkl")

#分别将实验数据和模拟数据标准化
xExpData = xScaler.transform(expData[inCols].values)
yExpData = yScaler.transform(expData[outCols].values)
xSimData = xScaler.transform(simData[inCols].values)
ySimData = yScaler.transform(simData[outCols].values)

#对实验数据切割训练测试集 而模拟数据则纯训练集
np.random.seed(seed)
testIndexs = np.random.choice(range(expData.shape[0]),int(expData.shape[0]*testRate),replace=False)
leftIndexs = [i for i in range(expData.shape[0]) if i not in testIndexs]
np.random.seed(seed)
valIndexs = np.random.choice(range(len(leftIndexs)),int(len(leftIndexs)*valRate),replace=False)
leftIndexs = [i for i in range(len(leftIndexs)) if i not in valIndexs]
trainIndexs = [i for i in range(expData.shape[0]) if i not in testIndexs]
xExpTrain = torch.FloatTensor(xExpData[trainIndexs])
xExpVal = torch.FloatTensor(xExpData[valIndexs])
xExpTest = torch.FloatTensor(xExpData[testIndexs])
yExpTrain = torch.FloatTensor(yExpData[trainIndexs])
yExpVal = torch.FloatTensor(yExpData[valIndexs])
yExpTest = torch.FloatTensor(yExpData[testIndexs])
xSimTrain = torch.FloatTensor(xSimData)
ySimTrain = torch.FloatTensor(ySimData)


def trainNN(model,xTrain,yTrain,xVal,yVal,xTest,yTest,mark=""):
    '''
    训练神经网络模型
    :param model:神经网络模型
    :param xTrain:训练输入
    :param yTrain:训练输出
    :param xVal:验证输入
    :param yVal:验证输出
    :param xTest:测试输入
    :param yTest:测试输出
    :param mark:标记
    :return:模型，训练测试集预测值
    '''
    #训练和测试神经网络
    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(filter(lambda p: p.requires_grad, model.parameters()), lr=lr)
    history = {"epoch":[],"train_loss":[],"val_loss":[],"test_loss":[]}
    #bar = tqdm(range(epochs))
    for epoch in range(epochs):
        #训练部分
        model.train()
        x = xTrain.reshape(-1,1,1,len(inCols))
        y = yTrain
        yPred = model(x)
        yTrainPred = data2numpy(yPred)
        loss = criterion(yPred, y)
        loss.backward()
        optimizer.step()
        optimizer.zero_grad()
        trainLoss = loss.detach().numpy()
        #验证部分
        model.eval()
        x = xVal.reshape(-1,1,1,len(inCols))
        y = yVal
        yPred = model(x)
        yValPred = data2numpy(yPred)
        loss = criterion(yPred, y)
        valLoss = loss.detach().numpy()
        #测试部分
        model.eval()
        x = xTest.reshape(-1,1,1,len(inCols))
        y = yTest
        yPred = model(x)
        yTestPred = data2numpy(yPred)
        loss = criterion(yPred, y)
        testLoss = loss.detach().numpy()
        #bar.set_description("%s train_loss:%.3f val_loss:%.3f test_loss:%.3f"%(mark,trainLoss,valLoss,testLoss))
        history["epoch"].append(epoch)
        history["train_loss"].append(trainLoss)
        history["val_loss"].append(valLoss)
        history["test_loss"].append(testLoss)
    #训练过程
    history = pd.DataFrame(history)
    #保存训练测试集结果
    yTrainPred = yScaler.inverse_transform(data2numpy(yTrainPred))
    yValPred = yScaler.inverse_transform(data2numpy(yValPred))
    yTestPred = yScaler.inverse_transform(data2numpy(yTestPred))
    yTrain = yScaler.inverse_transform(data2numpy(yTrain))
    yTest = yScaler.inverse_transform(data2numpy(yTest))
    xTrain = xScaler.inverse_transform(data2numpy(xTrain))
    xTest = xScaler.inverse_transform(data2numpy(xTest))
    trainData = np.concatenate([xTrain,yTrain,yTrainPred],axis=1)
    valData = np.concatenate([xVal,yVal,yValPred],axis=1)
    testData = np.concatenate([xTest, yTest, yTestPred], axis=1)
    cols = inCols + outCols + ["%s %s"%(mark,col) for col in outCols]
    trainData = pd.DataFrame(trainData,columns=cols)
    valData = pd.DataFrame(valData, columns=cols)
    testData = pd.DataFrame(testData, columns=cols)
    #计算测试集MSE
    testLoss = MSE(data2numpy(yTest),data2numpy(yTestPred))
    return model,history,trainData,valData,testData,valLoss,testLoss

def trainModelByParams(nodeNum,resNum,freezeNum,name,mode="cnn"):
    '''
    根据一组参数训练出基于CNN的残差网络 或 DNN网络
    :param nodeNum: 节点数
    :param resNum: 残差网络层数
    :param freezeNum: 冻结层数
    :param freezeNum: 保存模型名的前缀
    :param name: 模型前缀
    :param mode: CNN或DNN模式
    '''
    if mode.lower() == "cnn":
        model = ResCnnNet(nodeNum, resNum, len(inCols), len(outCols))
    else:
        model = ResFcNet(nodeNum, resNum, len(inCols), len(outCols))
    #先用实验数据训练 再用模拟数据训练
    model,history,trainData,valData,testData,valLoss,testLoss = trainNN(model,xExpTrain,yExpTrain,xExpVal,yExpVal,xExpTest,yExpTest,"%s-resCnnNet"%name)
    #冻结残差层前2层
    for i,child in enumerate(model.resList):
        if i<freezeNum:
            for param in child.parameters():
                param.requires_grad = False
    #使用模拟数据训练，注释掉就是只训练实验数据
    model,history,trainData,valData,testData,valLoss,testLoss = trainNN(model,xSimTrain,ySimTrain,xExpVal,yExpVal,xExpTest,yExpTest,"%s-resCnnNet"%name)
    return model,history,trainData,valData,testData,valLoss,testLoss

def saveResult(model,history,trainData,valData,testData,name,mode):
    '''保存模型训练结果'''
    name = "%sResCnn"%name if mode == "cnn" else "%sResDnn" % name
    torch.save(model, 'Static/%s.pth'% name)
    writer = pd.ExcelWriter("Result/%s训练结果.xlsx"%name)
    history.to_excel(writer,sheet_name="训练过程",index=None)
    trainData.to_excel(writer,sheet_name="训练预测",index=None)
    valData.to_excel(writer,sheet_name="验证预测",index=None)
    testData.to_excel(writer, sheet_name="测试预测", index=None)
    writer.close()

class MyProblem(ea.Problem):  # 继承Problem父类
    def __init__(self,nodeArea,resArea,freezeArea,name,mode):
        M = 1  # 优化目标个数
        maxormins = [1] * M  # 初始化maxormins（目标最小最大化标记列表，1：最小化该目标；-1：最大化该目标）
        Dim = 3  # 初始化Dim（决策变量维数）
        varTypes = [1,1,1]  # 初始化varTypes（决策变量的类型，0：实数；1：整数）
        lb = [nodeArea[0],resArea[0],freezeArea[0],]  # 决策变量下界
        ub = [nodeArea[1],resArea[1],freezeArea[1],]  # 决策变量上界
        lbin = [1,1,1]  # 决策变量下边界（0表示不包含该变量的下边界，1表示包含）
        ubin = [1,1,1]  # 决策变量上边界（0表示不包含该变量的上边界，1表示包含）
        # 调用父类构造方法完成实例化
        ea.Problem.__init__(self, 'MyProblem', M, maxormins, Dim, varTypes, lb, ub, lbin, ubin)
        self.mode = mode
        self.name = name
        self.bestValLoss = 1e+10
        self.bestValLossList = []
        self.meanValLossList = []
        self.bestArgs = []
        self.bestArg = None
        self.curGen = 0  # 当前迭代数

    def aimFunc(self, pop):  # 目标函数
        self.curGen += 1
        name = "%s_%s"%(self.name,self.mode)
        Vars = pop.Phen  # 得到决策变量矩阵
        ObjV = []
        meanLoss = []
        #根据该节点数训练神经网络
        bar = tqdm(range(Vars.shape[0]))
        for i in bar:
            model,history,trainData,valData,testData,valLoss,testLoss = trainModelByParams(Vars[i,0],Vars[i,1],Vars[i,2],self.name,self.mode)
            ObjV.append(valLoss)
            meanLoss.append(valLoss)
            if valLoss < self.bestValLoss:
                self.bestValLoss = valLoss
                # 保存最佳模型
                saveResult(model, history, trainData, valData, testData, self.name, self.mode)
                self.bestResult = (model, history, trainData, valData, testData, valLoss, testLoss)
                self.bestArg = Vars[i, :].tolist()
            bar.set_description("%s 种群:%d/%d best_val_loss:%.3f" % (name, self.curGen, MAXGEN, self.bestValLoss))
        self.bestArgs.append(self.bestArg)
        self.bestValLossList.append(self.bestValLoss)
        self.meanValLossList.append(np.mean(meanLoss))
        pop.ObjV = np.array(ObjV).reshape(-1, 1)

def saveGA(algorithm,problem,name):
    '''保存GA的训练过程'''
    #保存遗传算法迭代过程
    args = np.array(problem.bestArgs)
    log = algorithm.log
    bests = np.array(problem.bestValLossList)
    means = np.array(problem.meanValLossList)
    log = {"迭代次数":range(1,MAXGEN+1),"最优节点数":args[:,0],"最优残差块数":args[:,1],"最优冻结块数":args[:,2],"组内平均验证机损失":means,"最佳验证集损失":bests}
    log = pd.DataFrame(log)
    log.to_excel("Result/%s遗传算法迭代过程.xlsx"%name,index=None)

    fig,ax = plt.subplots(1,1)
    ax.plot(log["迭代次数"],log["最佳验证集损失"],label="全局最佳",color="#FF0000",linestyle="--")
    ax.plot(log["迭代次数"], log["组内平均验证机损失"], label="组内平均",color="#2894FF",linestyle="-",marker=".")
    ax.set_xlabel("epoch")
    ax.set_ylabel("验证集损失")
    ax.legend()
    fig.savefig('Result/%s遗传算法迭代过程.png'%name,dpi=500)




def plotTrain(history,name):
    '''画训练折线图'''
    fig, ax = plt.subplots(1, 1)
    ax.plot(history["epoch"], history["train_loss"], label="train_loss")
    ax.set_xlabel("epoch")
    ax.set_ylabel("loss")
    fig.savefig("Result/%s训练过程.png"%name, dpi=250)

def plotFeatureW(model,name):
    '''绘制特征权重'''
    lossResult = []
    for i,col in enumerate(inCols):
        xTest = deepcopy(xExpTest)
        yTest = deepcopy(yExpTest)
        np.random.seed(seed)
        np.random.shuffle(xTest[:,i])
        xTest = xTest.reshape(-1, 1, 1, len(inCols))
        yPred = model(xTest)
        loss = MAE(yTest.detach().numpy(),yPred.detach().numpy())
        lossResult.append({'feature': col, 'mae': loss})
    lossResult = pd.DataFrame(lossResult)
    lossResult = lossResult.sort_values('mae')

    fig, ax = plt.subplots(1, 1)
    ax.barh(np.arange(len(inCols)),lossResult.mae)
    ax.set_yticks(np.arange(len(inCols)), [f[:5]+"..." for f in lossResult.feature.values])
    fig.savefig("Result/%s特征权重.png"%name, dpi=250)
    lossResult.to_excel("Result/%s特征权重.xlsx"%name,index=False)


if __name__ == "__main__":
    # 默认模型 参数为区间均值
    defaultNode = np.mean(nodeArea)
    defaultRes = np.mean(resArea)
    defaultFreeze = np.mean(freezeArea)
    print("正在训练默认模型...")
    #训练默认网络
    defaultCnn, defaultCnnHistory, defaltCnnTrainData, defalultCnnValData, defaultCnnTestData, defaultCnnValLoss, defaultCnnTestLoss = trainModelByParams(defaultNode,defaultRes,defaultFreeze,"default",mode="cnn")
    saveResult(defaultCnn, defaultCnnHistory, defaltCnnTrainData, defalultCnnValData, defaultCnnTestData,"default",mode="cnn")
    defaultDnn, defaultDnnHistory, defaltDnnTrainData, defalultDnnValData, defaultDnnTestData, defaultDnnValLoss, defaultDnnTestLoss = trainModelByParams(defaultNode,defaultRes,defaultFreeze,"default",mode="dnn")
    saveResult(defaultDnn, defaultDnnHistory, defaltDnnTrainData, defalultDnnValData, defaultDnnTestData,"default",mode="dnn")
    print("正在训练GA模型...")
    #GA优化模型
    cnnProblem = MyProblem(nodeArea,resArea,freezeArea,"GA","cnn")  # 生成问题对象
    cnnAlgorithm = ea.soea_SGA_templet(cnnProblem, ea.Population(Encoding='RI', NIND=NIND), MAXGEN=MAXGEN, logTras=1)
    cnnRes = ea.optimize(cnnAlgorithm, verbose=True, drawing=0, outputMsg=True, drawLog=False, saveFlag=False,dirName='Result')
    saveGA(cnnAlgorithm,cnnProblem, "Cnn")

    dnnProblem = MyProblem(nodeArea,resArea,freezeArea,"GA","dnn")  # 生成问题对象
    dnnAlgorithm = ea.soea_SGA_templet(dnnProblem, ea.Population(Encoding='RI', NIND=NIND), MAXGEN=MAXGEN, logTras=1)
    dnnRes = ea.optimize(dnnAlgorithm, verbose=True, drawing=0, outputMsg=True, drawLog=False, saveFlag=False,dirName='Result')
    saveGA(dnnAlgorithm,dnnProblem, "Dnn")

    #可视化对比
    fig,ax = plt.subplots(1,1)
    y = [defaultCnnTestLoss,cnnProblem.bestResult[-1],defaultDnnTestLoss,dnnProblem.bestResult[-1]]
    ax.bar(range(4),y,width=0.5,align='center',color='black',alpha = 0.8)
    ax.set_ylabel("测试集MSE")
    ax.set_xticks(range(len(y)))
    ax.set_xticklabels(["default CNN ResNet","GA CNN ResNet","default DNN ResNet","GA DNN ResNet"])
    for x, y in zip(range(len(y)), y):  # zip是将X，Y1分别传到x,y中，传两个
        plt.text(x, y + 0.001, '%.3f' % y, ha='center', va='bottom')  # ha,va规定坐标表示的点，默认左下
    fig.savefig("Result/测试MSE对比.png",dpi=250)

    plotTrain(defaultCnnHistory,"default CNN ResNet")
    plotTrain(defaultDnnHistory, "default DNN ResNet")
    plotTrain(cnnProblem.bestResult[1], "GA CNN ResNet")
    plotTrain(dnnProblem.bestResult[1], "GA DNN ResNet")

    plotFeatureW(defaultCnn,"default CNN ResNet")
    plotFeatureW(defaultDnn, "default DNN ResNet")
    plotFeatureW(cnnProblem.bestResult[0], "GA CNN ResNet")
    plotFeatureW(dnnProblem.bestResult[0], "GA DNN ResNet")

