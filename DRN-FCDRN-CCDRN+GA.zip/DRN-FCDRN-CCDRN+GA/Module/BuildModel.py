from sklearn.neural_network import BernoulliRBM
import torch.nn as nn
import torch.nn.functional as F
import torch
import numpy as np
import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')#使用GPU CPU

def data2numpy(data):
    '''张量转为CPU的numpy类型'''
    try:
        return data.detach().cpu().numpy()
    except:
        return data


class ResConvBlock(nn.Module):
    def __init__(self,nodeNum):
        super(ResConvBlock, self).__init__()
        # 这里定义了残差块内连续的2个卷积层
        self.left = nn.Sequential(
            nn.Conv2d(nodeNum, nodeNum, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(nodeNum),
            nn.PReLU(),  # 可以改成 nn.PReLU()
            nn.Conv2d(nodeNum, nodeNum, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(nodeNum)
        )
        self.relu = nn.PReLU()

    def forward(self, x):
        out = self.left(x)
        # 将2个卷积层的输出跟处理过的x相加，实现ResNet的基本结构
        out = x + out
        out = self.relu(out)
        return out

class ResFcBlock(nn.Module):
    def __init__(self, nodeNum):
        super(ResFcBlock, self).__init__()
        # 这里定义了残差块内连续的2个卷积层
        self.left = nn.Sequential(
            nn.Linear(nodeNum, nodeNum),
            nn.BatchNorm1d(nodeNum),
            nn.PReLU(),  # 可以改成 nn.PReLU()
            nn.Linear(nodeNum, nodeNum),
            nn.BatchNorm1d(nodeNum)
        )
        self.relu = nn.PReLU()

    def forward(self, x):
        out = self.left(x)
        # 将2个卷积层的输出跟处理过的x相加，实现ResNet的基本结构
        out = x + out
        out = self.relu(out)
        return out

class ResCnnNet(nn.Module):
    '''基于CNN的残差网络'''
    def __init__(self,nodeNum,resNum,inDim,outDim):
        super(ResCnnNet, self).__init__()
        nodeNum = int(nodeNum)
        resNum = int(resNum)
        inDim = int(inDim)
        outDim = int(outDim)
        self.inDim = inDim
        #修改通道供给残差块
        self.conv1 = nn.Conv2d(1, nodeNum, kernel_size=3, stride=1, padding=1)
        #残差层
        self.resList = [ResConvBlock(nodeNum) for i in range(resNum)]
        self.resList = nn.ModuleList(self.resList)
        self.conv2 = nn.Conv2d(nodeNum, 1, kernel_size=3, stride=1, padding=1)
        self.relu = nn.PReLU()
        #输出层
        self.fc = nn.Linear(inDim,outDim)

    def forward(self,x):
        x1 = self.conv1(x)
        x = x1
        for layer in self.resList:
            x = layer(x)
        x = x1 + x
        x = self.relu(x)
        x = self.conv2(x)
        x = x.reshape(-1,self.inDim)
        x = self.fc(x)
        return x

class ResFcNet(nn.Module):
    '''基于全连接的残差网络'''
    def __init__(self,nodeNum,resNum,inDim,outDim):
        super(ResFcNet, self).__init__()
        nodeNum = int(nodeNum)
        resNum = int(resNum)
        inDim = int(inDim)
        outDim = int(outDim)
        self.inDim = inDim
        #修改节点数供给残差块
        self.fc1 = nn.Linear(inDim,nodeNum)
        #残差层
        self.resList = [ResFcBlock(nodeNum) for i in range(resNum)]
        self.resList = nn.ModuleList(self.resList)
        self.relu = nn.PReLU()
        #输出层
        self.fc2 = nn.Linear(nodeNum,outDim)

    def forward(self,x):
        x = x.reshape(-1,self.inDim)
        x1 = self.fc1(x)
        x = x1
        for layer in self.resList:
            x = layer(x)
        x = x1 + x
        x = self.relu(x)
        x = self.fc2(x)
        return x

if __name__ == "__main__":
    x = torch.zeros(2,1,1,2)
    resCnnNet = ResCnnNet(50,3,2,1)
    resFcNet = ResFcNet(50,3,2,1)
    print(resCnnNet(x).shape)
    print(resFcNet(x).shape)